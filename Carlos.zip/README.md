TO RUN TEST
    
    npm install
    npm run start
    
    
   src/ contains Coding tests files
  
   
   test/ Contains test files (Not time to complete all tests)
   
   data/ Contains Bulk FIles to execute the Coding Exercise.
