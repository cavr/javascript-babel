class Player {
  constructor(nickname) {
    this.nickname = nickname;
  }
}

module.exports = Player;
