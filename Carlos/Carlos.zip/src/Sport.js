

class Sport {
  constructor(sport) {
    this.sport = sport;
  }
}

module.exports = Sport;
